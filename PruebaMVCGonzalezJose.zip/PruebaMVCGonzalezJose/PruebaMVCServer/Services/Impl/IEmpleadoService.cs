﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PruebaMVCData.Models;

namespace ProyectoMVCServer.Services
{
    public interface IEmpleadoService
    {
        Task<List<Empleado>> GetAllEmpleadosAsync();
        Task<Empleado> GetEmpleadoByIdAsync(int id);
        Task AddEmpleadoAsync(Empleado empleado);
        Task UpdateEmpleadoAsync(Empleado empleado);
        Task DeleteEmpleadoAsync(int id);
    }
}
