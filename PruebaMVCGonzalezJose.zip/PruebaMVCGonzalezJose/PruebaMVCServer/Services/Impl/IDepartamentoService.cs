﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PruebaMVCData.Models;

namespace ProyectoMVCServer.Services
{
    public interface IDepartamentoService
    {
        Task<List<Departamento>> GetAllDepartamentosAsync();
        Task<Departamento> GetDepartamentoByIdAsync(int id);
        Task AddDepartamentoAsync(Departamento departamento);
        Task UpdateDepartamentoAsync(Departamento departamento);
        Task DeleteDepartamentoAsync(int id);
    }
}
