﻿using Microsoft.EntityFrameworkCore;
using PruebaMVCData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaMVCData
{
    public class Conexion: DbContext
    {
        public DbSet<Empleado> Empleados { get; set; }
        public DbSet<Departamento> Departamentos{ get; set; }
        public Conexion(DbContextOptions<Conexion> conex): base(conex)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Departamento>(entity => 
            {
                entity.HasKey(d => d.IdDepartamento);
            });

            modelBuilder.Entity<Empleado>(entity =>
            {
                entity.HasKey(e => e.IdEmpleado);

                entity.HasOne(e => e.Departamentos)
                    .WithMany()
                    .HasForeignKey(e => e.IdDepartamento)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Jefes)
                    .WithMany()
                    .HasForeignKey(e => e.IdJefe)
                    .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}
