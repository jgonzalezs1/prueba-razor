﻿using Microsoft.AspNetCore.Mvc;
using ProyectoMVCServer.Services;
using PruebaMVCData.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProyectoMVCServer.Controllers
{
    [Route("api/empleado")]
    [ApiController]
    public class EmpleadoController : ControllerBase
    {
        private readonly IEmpleadoService _empleadoService;

        public EmpleadoController(IEmpleadoService empleadoService)
        {
            _empleadoService = empleadoService;
        }

        [HttpGet("obtener-empleados")]
        public async Task<ActionResult<List<Empleado>>> GetAllEmpleados()
        {
            try
            {
                var empleados = await _empleadoService.GetAllEmpleadosAsync();
                return Ok(empleados);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("obtener-empleados/{id}")]
        public async Task<ActionResult<Empleado>> GetEmpleadoById(int id)
        {
            try
            {
                var empleado = await _empleadoService.GetEmpleadoByIdAsync(id);
                if (empleado == null)
                {
                    return NotFound($"Empleado with id {id} not found");
                }
                return Ok(empleado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("registrar-empleados")]
        public async Task<ActionResult<Empleado>> AddEmpleado(Empleado empleado)
        {
            try
            {
                await _empleadoService.AddEmpleadoAsync(empleado);
                return CreatedAtAction(nameof(GetEmpleadoById), new { id = empleado.IdEmpleado }, empleado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("actualizar-empleados/{id}")]
        public async Task<ActionResult> UpdateEmpleado(int id, Empleado empleado)
        {
            try
            {
                if (id != empleado.IdEmpleado)
                {
                    return BadRequest("ID mismatch");
                }

                await _empleadoService.UpdateEmpleadoAsync(empleado);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("eliminar-empleados/{id}")]
        public async Task<ActionResult> DeleteEmpleado(int id)
        {
            try
            {
                await _empleadoService.DeleteEmpleadoAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
