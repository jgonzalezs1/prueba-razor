﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PruebaMVCData.Models;
using PruebaMVCData.Repositories.Impl;

namespace ProyectoMVCServer.Services
{
    public class DepartamentoService : IDepartamentoService
    {
        private readonly IDepartamentoRepository _departamentoRepository;

        public DepartamentoService(IDepartamentoRepository departamentoRepository)
        {
            _departamentoRepository = departamentoRepository;
        }

        public async Task<List<Departamento>> GetAllDepartamentosAsync()
        {
            return await _departamentoRepository.GetAllDepartamentosAsync();
        }

        public async Task<Departamento> GetDepartamentoByIdAsync(int id)
        {
            return await _departamentoRepository.GetDepartamentoByIdAsync(id);
        }

        public async Task AddDepartamentoAsync(Departamento departamento)
        {
            await _departamentoRepository.AddDepartamentoAsync(departamento);
        }

        public async Task UpdateDepartamentoAsync(Departamento departamento)
        {
            await _departamentoRepository.UpdateDepartamentoAsync(departamento);
        }

        public async Task DeleteDepartamentoAsync(int id)
        {
            await _departamentoRepository.DeleteDepartamentoAsync(id);
        }
    }
}
