﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using PruebaMVCData.Models;

namespace PruebaMVCClient.Components.Services
{
    public class EmpleadoService
    {
        private readonly HttpClient _httpClient;

        public EmpleadoService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Empleado>> GetEmpleadosAsync()
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/empleado/obtener-empleados";

            return await _httpClient.GetFromJsonAsync<List<Empleado>>(endPoint);
        }

        public async Task<Empleado> GetEmpleadoByIdAsync(int id)
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/empleado/obtener-empleados/{id}";

            return await _httpClient.GetFromJsonAsync<Empleado>(endPoint);
        }

        public async Task CreateEmpleadoAsync(Empleado empleados)
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/empleado/registrar-empleados";

            await _httpClient.PostAsJsonAsync(endPoint, empleados);
        }

        public async Task UpdateEmpleadoAsync(Empleado empleados)
        {
            var id = empleados.IdEmpleado;
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/empleado/actualizar-empleados/api/{id}";

            await _httpClient.PutAsJsonAsync(endPoint, empleados);
        }

        public async Task DeleteEmpleadoAsync(int id)
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/empleado/eliminar-empleados/api/{id}";

            await _httpClient.DeleteAsync(endPoint);
        }
    }
}
