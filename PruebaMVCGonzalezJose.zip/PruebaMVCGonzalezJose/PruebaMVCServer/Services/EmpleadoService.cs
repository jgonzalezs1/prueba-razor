﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PruebaMVCData.Models;
using PruebaMVCData.Repositories.Impl;

namespace ProyectoMVCServer.Services
{
    public class EmpleadoService : IEmpleadoService
    {
        private readonly IEmpleadoRepository _empleadoRepository;

        public EmpleadoService(IEmpleadoRepository empleadoRepository)
        {
            _empleadoRepository = empleadoRepository;
        }

        public async Task<List<Empleado>> GetAllEmpleadosAsync()
        {
            return await _empleadoRepository.GetAllEmpleadosAsync();
        }

        public async Task<Empleado> GetEmpleadoByIdAsync(int id)
        {
            return await _empleadoRepository.GetEmpleadoByIdAsync(id);
        }

        public async Task AddEmpleadoAsync(Empleado empleado)
        {
            await _empleadoRepository.AddEmpleadoAsync(empleado);
        }

        public async Task UpdateEmpleadoAsync(Empleado empleado)
        {
            await _empleadoRepository.UpdateEmpleadoAsync(empleado);
        }

        public async Task DeleteEmpleadoAsync(int id)
        {
            await _empleadoRepository.DeleteEmpleadoAsync(id);
        }
    }
}
