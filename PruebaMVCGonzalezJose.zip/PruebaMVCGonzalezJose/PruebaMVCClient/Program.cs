using PruebaMVCClient.Components;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using PruebaMVCClient.Components.Services;

// Crear el constructor del builder
var builder = WebApplication.CreateBuilder(args);

// A�adir configuraci�n de variables de entorno
builder.Configuration.AddEnvironmentVariables();

// Obtener la URL de la API desde la configuraci�n
var apiUrl = builder.Configuration["API_URL"] ?? throw new Exception("API_URL is not configured.");

// Add services to the container.
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(apiUrl) });
builder.Services.AddScoped<DepartamentoService>();
builder.Services.AddScoped<EmpleadoService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
