﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaMVCData.Models
{
    public class Empleado
    {
        public int IdEmpleado { get; set; }
        [Required]
        public string? DNIEmpleado { get; set; }
        [Required]
        public string? NombreEmpleado { get; set; }
        [Required]
        public char? GeneroEmpleado { get; set; }
        [Required]
        public DateOnly FechaNacimiento { get; set; }
        [Required]
        public DateOnly FechaIncorporacion { get; set; }
        [Required]
        public float SalarioEmpleado { get; set; }
        [Required]
        public float ComisionEmpleado { get; set; }
        [Required]
        public float CargoEmpleado { get; set; }
        [Required]
        public int IdJefe { get; set; }
        [Required]
        public int IdDepartamento { get; set; }
        public Empleado? Jefes { get; set; }
        public Departamento? Departamentos { get; set; }
    }
}
