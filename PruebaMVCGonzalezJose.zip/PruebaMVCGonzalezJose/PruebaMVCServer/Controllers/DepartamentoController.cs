﻿using Microsoft.AspNetCore.Mvc;
using ProyectoMVCServer.Services;
using PruebaMVCData.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProyectoMVCServer.Controllers
{
    [Route("api/departamento")]
    [ApiController]
    public class DepartamentoController : ControllerBase
    {
        private readonly IDepartamentoService _departamentoService;

        public DepartamentoController(IDepartamentoService departamentoService)
        {
            _departamentoService = departamentoService;
        }

        [HttpGet("obtener-departamentos")]
        public async Task<ActionResult<List<Departamento>>> GetAllDepartamentos()
        {
            try
            {
                var departamentos = await _departamentoService.GetAllDepartamentosAsync();
                return Ok(departamentos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("obtener-departamentos/{id}")]
        public async Task<ActionResult<Departamento>> GetDepartamentoById(int id)
        {
            try
            {
                var departamento = await _departamentoService.GetDepartamentoByIdAsync(id);
                if (departamento == null)
                {
                    return NotFound($"Departamento with id {id} not found");
                }
                return Ok(departamento);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("registrar-departamentos")]
        public async Task<ActionResult> AddDepartamento(Departamento departamento)
        {
            try
            {
                await _departamentoService.AddDepartamentoAsync(departamento);
                return CreatedAtAction(nameof(GetDepartamentoById), new { id = departamento.IdDepartamento }, departamento);

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("actualizar-departamentos/{id}")]
        public async Task<ActionResult> UpdateDepartamento(int id, Departamento departamento)
        {
            try
            {
                if (id != departamento.IdDepartamento)
                {
                    return BadRequest("ID mismatch");
                }

                await _departamentoService.UpdateDepartamentoAsync(departamento);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("eliminar-departamentos/{id}")]
        public async Task<ActionResult> DeleteDepartamento(int id)
        {
            try
            {
                await _departamentoService.DeleteDepartamentoAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
