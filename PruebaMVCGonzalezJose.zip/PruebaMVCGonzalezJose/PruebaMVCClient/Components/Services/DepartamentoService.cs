﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using PruebaMVCData.Models;

namespace PruebaMVCClient.Components.Services
{
    public class DepartamentoService
    {
        private readonly HttpClient _httpClient;

        public DepartamentoService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Departamento>> GetDepartamentosAsync()
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/departamento/obtener-departamentos";

            return await _httpClient.GetFromJsonAsync<List<Departamento>>(endPoint);
        }

        public async Task<Departamento> GetDepartamentoByIdAsync(int id)
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/departamento/obtener-departamentos/{id}";

            return await _httpClient.GetFromJsonAsync<Departamento>(endPoint);
        }

        public async Task CreateDepartamentoAsync(Departamento departamentos)
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/departamento/registrar-departamentos";

            await _httpClient.PostAsJsonAsync(endPoint, departamentos);
        }

        public async Task UpdateDepartamentoAsync(Departamento departamentos)
        {
            var id = departamentos.IdDepartamento;
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/departamento/actualizar-departamentos/api/{id}";

            await _httpClient.PutAsJsonAsync(endPoint, departamentos);
        }

        public async Task DeleteDepartamentoAsync(int id)
        {
            var apiURL = Environment.GetEnvironmentVariable("API_URL");
            var endPoint = $"{apiURL}/api/departamento/eliminar-departamentos/api/{id}";

            await _httpClient.DeleteAsync(endPoint);
        }
    }
}
